# LifeOS 新 Logo 交接说明（主人已于 2026-10-22 定稿）

**主人明确决定**：Logo 定为「叠纸」（两张小圆角纸片一左一右各歪 9°，重叠处暖沙色）。
主人不喜欢亮蓝，登录页、侧栏、启动面、图标里的 `#315DFA` 蓝底都要去掉。
这是主人亲口确认的定稿，可按"主人确认"写入 DESIGN.md。

## 色值（本 Logo 专用）
| 用途 | 色值 | 来源 |
|---|---|---|
| 深色底块 | `#4D5869` | 日记正文灰蓝（DESIGN.md 第 3 节） |
| 纸片线条（深底） | `#F1ECDB` | 登录底图抽样的米白 |
| 重叠处暖沙 | `#E3D3AE` | 设计时新定，不是已有 token |
| 浅色版底块 / 描边 | `#F1F2F3` / `#DCE0E4` | `--control-tray` / `--control-line` |
| 浅色版线条 | `#41484F` | `--control-ink` |

几何：viewBox 64×64，底块圆角 16；两张纸 26×32、rx 5、线宽 3.5，
一张 `rotate(-9 27 28)`，一张 `rotate(9 37 36)`。

## 文件与要替换的位置
| 新文件 | 替换 | 备注 |
|---|---|---|
| `favicon.svg` | `apps/web/public/favicon.svg` | 登录页（两处）、侧栏 28px、启动面 40px、WelcomeGate 都引用它 |
| `icon-192.png`、`icon-512.png` | `apps/web/public/` 同名文件 | Manifest 的 any 图标 |
| `icon-maskable-512.png` | `apps/web/public/icon-maskable-512.png` | 满铺底色，图形缩到 85% 留安全区 |
| `icon-maskable.svg` | `apps/web/public/icon-maskable.svg` | 仓库里已有这个文件 |
| `apple-touch-icon.png` | `apps/web/public/apple-touch-icon.png` | 180×180，满铺方形，由 iOS 自己切圆角 |
| `favicon-light.svg` | 暂不接线 | 浅色底场景备用 |

## 同时要改的蓝
1. `index.html:8` 的 `/favicon.svg?v=2`：**把版本号升到 `?v=3`**，否则浏览器会继续显示缓存的蓝色旧图。登录页和侧栏等处引用的同样带 `?v=2` 的地方也要一起改。
2. `site.webmanifest` 的 `theme_color` 目前是 `#315dfa`，建议改成与 HTML 一致的 `#eef2f7`。`background_color` 的 `#f5f7fb` 可顺手对齐到 `#eef2f7`，请主人定。
3. **AI 管家 Logo**（`assistant-logo-path.ts` + `AIAssistant.tsx` 的 `#60A5FA→#3370FF` 蓝渐变）不在本次范围，是否一并去蓝请**先问主人**，不要自行改。
4. `changelog.md:7871` 写着"logo 的蓝渐变保留：它是品牌标识"，这是旧决定，已被主人今天的决定取代，写 changelog 时请注明。

## 按 AGENTS.md 办
- 改完追加 changelog（带 `AI:` 署名），并在 DESIGN.md 记一条 Logo 定案。
- 视觉验收用 CDP 断言（图片请求成功、尺寸，`<img>` 命中新文件），不要主动出截图。
- 验收只能用隔离实例，**不要在 3011/5199 上跑会写入的脚本**。
- `commit` 可以做，`push` 先问。
- 修改 `login-intro.tsx`、`shell-nav.tsx`、`dialogs.tsx` 等界面文件之前，先按"UI 施工与交付门槛"登记设计依据。

## 未验证
- 只在 16 / 32 / 180 / 192 / 512 px 做过渲染自检，没有在真实浏览器标签页、iOS 主屏、安卓 maskable 裁切下看过。
- 暖沙 `#E3D3AE` 在登录页柔雾底图上的实际观感待主人体验。
